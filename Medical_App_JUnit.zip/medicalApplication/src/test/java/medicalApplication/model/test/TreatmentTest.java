package medicalApplication.model.test;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;

import medical.com.medicalApplication.model.Treatment;

public class TreatmentTest {
	
	private static Treatment treatment;
	
	@BeforeClass
	public static void BeforeClass() {
		treatment = new Treatment("Date", "Diag", "Desc");
	}

	@Test
	public void testGetTreatmentDate() {
		assertTrue(treatment.getTreatmentDate().equals("Date"));
	}

	@Test
	public void testSetTreatmentDate() {
		treatment.setTreatmentDate("Date2");
		assertTrue(treatment.getTreatmentDate().equals("Date2"));
		treatment.setTreatmentDate("Date");
	}

	@Test
	public void testGetDiagnose() {
		assertTrue(treatment.getDiagnose().equals("Diag"));
	}

	@Test
	public void testSetDiagnose() {
		treatment.setDiagnose("Diag2");
		assertTrue(treatment.getDiagnose().equals("Diag2"));
		treatment.setDiagnose("Diag");
	}

	@Test
	public void testGetDescription() {
		assertTrue(treatment.getDescription().equals("Desc"));
	}

	@Test
	public void testSetDescription() {
		treatment.setDescription("Desc2");
		assertTrue(treatment.getDescription().equals("Desc2"));
		treatment.setDescription("Desc");
	}

	@Test
	public void testToString() {
		assertTrue(treatment.toString().equals("Treatment:  Date: Date Diagnose: Diag"));
	}

}
