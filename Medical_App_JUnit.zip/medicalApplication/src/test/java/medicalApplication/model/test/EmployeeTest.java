package medicalApplication.model.test;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;

import medical.com.medicalApplication.model.Employee;

public class EmployeeTest {
	
	private static Employee employee;
	
	@BeforeClass
	public static void BeforeClass() {
		employee = new Employee("Employee Name","12345");
	}

	@Test
	public void testGetName() {
		assertTrue(employee.getName().equals("Employee Name"));
	}

	@Test
	public void testGetId() {
		assertTrue(employee.getId().equals("12345"));
	}

	@Test
	public void testGetPassword() {
		assertTrue(employee.getPassword().equals("Open"));
	}

}
