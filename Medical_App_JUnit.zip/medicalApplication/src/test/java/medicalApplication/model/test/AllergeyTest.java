package medicalApplication.model.test;

import static org.junit.Assert.*;

import org.junit.BeforeClass;

import org.junit.Test;

import medical.com.medicalApplication.model.Allergey;

public class AllergeyTest {
	private static Allergey allergey;
	
	@BeforeClass
	public static void BeforeClass() {
		
		allergey = new Allergey("AllergeyName");
		
	}

	@Test
	public void testGetName() {
		assertTrue(allergey.getName().equals("AllergeyName"));
	}

	@Test
	public void testSetName() {
		allergey.setName("AllergeyName2");
		assertTrue(allergey.getName().equals("AllergeyName2"));
		allergey.setName("AllergeyName");
	}

	@Test
	public void testToString() {
		assertTrue(allergey.toString().equals("Allergy AllergeyName"));
	}

}
