package medicalApplication.model.test;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.BeforeClass;

import medical.com.medicalApplication.model.Medication;

public class MedicationTest {
	
	private static Medication medication;
	
	@BeforeClass
	public static void BeforeClass() {
		medication = new Medication("Name", "StartDate", "EndDate", "Dose");
	}

	@Test
	public void testGetName() {
		assertTrue(medication.getName().equals("Name"));
	}

	@Test
	public void testSetName() {
		medication.setName("Name2");
		assertTrue(medication.getName().equals("Name2"));
		medication.setName("Name");
	}

	@Test
	public void testGetStartDate() {
		assertTrue(medication.getStartDate().equals("StartDate"));
	}

	@Test
	public void testSetStartDate() {
		medication.setStartDate("StartDate2");
		assertTrue(medication.getStartDate().equals("StartDate2"));
		medication.setStartDate("StartDate");
	}

	@Test
	public void testGetEndDate() {
		assertTrue(medication.getEndDate().equals("EndDate"));
	}

	@Test
	public void testSetEndDate() {
		medication.setEndDate("EndDate2");
		assertTrue(medication.getEndDate().equals("EndDate2"));
		medication.setEndDate("EndDate");
	}

	@Test
	public void testGetDose() {
		assertTrue(medication.getDose().equals("Dose"));
	}

	@Test
	public void testSetDose() {
		medication.setDose("Dose2");
		assertTrue(medication.getDose().equals("Dose2"));
		medication.setDose("Dose");
	}

	@Test
	public void testToString() {
		assertTrue(medication.toString().equals("Medication:Name Start Date: StartDate End Date: EndDate Dose: Dose"));
	}

}
