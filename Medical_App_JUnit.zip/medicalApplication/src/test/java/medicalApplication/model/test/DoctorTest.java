package medicalApplication.model.test;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;

import medical.com.medicalApplication.model.Doctor;

public class DoctorTest {
	private static Doctor doctor;
	
	@BeforeClass
	public static void BeforeClass() {
		doctor = new Doctor("Dr Name", "12345");
	}

	@Test
	public void testGetName() {
		assertTrue(doctor.getName().equals("Dr Name"));
	}

	@Test
	public void testSetName() {
		doctor.setName("Dr Name2");
		assertTrue(doctor.getName().equals("Dr Name2"));
		doctor.setName("Dr Name");
	}

	@Test
	public void testGetId() {
		assertTrue(doctor.getId().equals("12345"));
	}

	@Test
	public void testSetId() {
		doctor.setId("01234");
		assertTrue(doctor.getId().equals("01234"));
		doctor.setId("12345");
	}

	@Test
	public void testToString() {
		assertTrue(doctor.toString().equals("Doctor Name:Dr Name ID: 12345"));
	}

}
