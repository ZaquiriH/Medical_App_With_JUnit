package medicalApplication.model.test;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;

import medical.com.medicalApplication.model.Allergey;
import medical.com.medicalApplication.model.MedicalRecord;
import medical.com.medicalApplication.model.Medication;
import medical.com.medicalApplication.model.Patient;
import medical.com.medicalApplication.model.Treatment;

public class MedicalRecordTest {
	
	private static MedicalRecord medicalrecord;
	
	@BeforeClass
	public static void BeforeClass() {

		medicalrecord = new MedicalRecord(new Patient("First Last", "454"));
		
		medicalrecord.getHistory().addAllergy(new Allergey("Allergey Name"));
		medicalrecord.getHistory().addMedication(new Medication("Med Name","1/2/2019","5/2/2019","Dose Name"));
		medicalrecord.getHistory().addTreatment(new Treatment("1/2/2019", "Diagnose name","Description"));
	}

	@Test
	public void testGetPatient() {
		assertTrue(medicalrecord.getPatient().getName().equals("First Last"));
	}

	@Test
	public void testGetHistory() {
		assertTrue(medicalrecord.getHistory().getAlergies().stream().anyMatch(Allergey -> Allergey.getName().equals("Allergey Name")) 
				&& medicalrecord.getHistory().getAllMedications().stream().anyMatch(Medication -> Medication.getName().equals("Med Name"))
				&& medicalrecord.getHistory().getAllTreatments().stream().anyMatch(Treatment -> Treatment.getDiagnose().equals("Diagnose name"))
				&& medicalrecord.getPatient().getId().equals("454")
				);
	}

}
