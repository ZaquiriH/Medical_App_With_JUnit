package medicalApplication.model.test;

import static org.junit.Assert.*;


import org.junit.BeforeClass;
import org.junit.Test;

import medical.com.medicalApplication.model.Allergey;
import medical.com.medicalApplication.model.Medication;
import medical.com.medicalApplication.model.PatientHistory;
import medical.com.medicalApplication.model.Treatment;

public class PatientHistoryTest {
	
	private static PatientHistory patienthistory;
	
	private static PatientHistory patienthis2;

	private static Treatment treatment;
	private static Medication medication;
	private static Allergey allergy;
	
	private static Medication meds;
	
	
	@BeforeClass
	public static void BeforeClass() {
		patienthistory = new PatientHistory();


		treatment = new Treatment("Date", "Diag", "Desc");
		medication = new Medication("Name", "Start", "End", "Dose");
		allergy = new Allergey("Name");		
				
		patienthis2 = new PatientHistory();
		
		meds = new Medication("Water", "Now", "Later", "All");
		
	}

	@Test
	public void testAddTreatment() {
		patienthistory.addTreatment(treatment);
		assertTrue(patienthistory.getAllTreatments().contains(treatment));
	}

	@Test
	public void testAddAllergy() {
		patienthistory.addAllergy(allergy);
		assertTrue(patienthistory.getAlergies().contains(allergy));
	}

	@Test
	public void testAddMedication() {
		patienthistory.addMedication(medication);
		assertTrue(patienthistory.getAllMedications().contains(medication));
	}

	@Test
	public void testGetAlergies() {
		patienthistory.addAllergy(allergy);
		assertTrue(patienthistory.getAlergies().contains(allergy));
	}

	@Test
	public void testGetAllTreatments() {
		patienthistory.addTreatment(treatment);
		assertTrue(patienthistory.getAllTreatments().contains(treatment));
	}

	@Test
	public void testGetAllMedications() {
		patienthistory.addMedication(medication);
		assertTrue(patienthistory.getAllMedications().contains(medication));
	}
	@Test
	public void testMedsWithoutTreatment() {
		patienthis2.addMedication(meds);
		assertFalse("Allows medication without treatment assigned first.", patienthis2.getAllMedications().stream().count() > 0
				&& patienthis2.getAllTreatments().stream().count() <= 0
				);
	}
	public void testOneToMany() {
		
	}

}
