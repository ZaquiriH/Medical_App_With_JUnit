package medicalApplication.model.test;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;

import medical.com.medicalApplication.model.Patient;

public class PatientTest {
	
	private static Patient patient;
	
	@BeforeClass
	public static void BeforeClass() {
		patient = new Patient("Name", "12345");
	}

	@Test
	public void testGetName() {
		assertTrue(patient.getName().equals("Name"));
	}

	@Test
	public void testSetName() {
		patient.setName("Name2");
		assertTrue(patient.getName().equals("Name2"));
		patient.setName("Name");
	}

	@Test
	public void testGetId() {
		assertTrue(patient.getId().equals("12345"));
	}

	@Test
	public void testSetId() {
		patient.setId("01234");
		assertTrue(patient.getId().equals("01234"));
		patient.setId("12345");
	}

	@Test
	public void testToString() {
		assertTrue(patient.toString().equals("Patient Name: Name ID: 12345"));
	}

}
