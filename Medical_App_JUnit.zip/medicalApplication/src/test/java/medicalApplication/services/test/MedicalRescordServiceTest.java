package medicalApplication.services.test;

import static org.junit.Assert.*;

import java.util.List;
import java.util.stream.Collectors;

import org.junit.BeforeClass;
import org.junit.Test;

import medical.com.medicalApplication.model.Allergey;
import medical.com.medicalApplication.model.Medication;
import medical.com.medicalApplication.model.Patient;
import medical.com.medicalApplication.services.MedicalRescordService;

public class MedicalRescordServiceTest {
	
	
	@BeforeClass
	public static void BeforeClass() {
		MedicalRescordService.getReference().addPatient("Zero", "0000");
		MedicalRescordService.getReference().addPatient("One", "1111");
		
	}

	@Test
	public void testAddPatient() {
		MedicalRescordService.getReference().addPatient("Two", "2222");
		assertTrue(MedicalRescordService.getReference().getAllPatients().stream().count() == 3 );
		MedicalRescordService.getReference().addPatient("Three", "2222");
		assertFalse("Allows patients with the same ID.", MedicalRescordService.getReference().getAllPatients().stream().count() == 4 );
	}

	@Test
	public void testGetMedicalRecord() {
		MedicalRescordService.getReference().getMedicalRecord("0000").getPatient().getName().equals("Zero");
//		MedicalRescordService.getReference().
	}

	@Test
	public void testGetPatient() {
		assertTrue(MedicalRescordService.getReference().getPatient("0000").getId().equals("0000"));
	}

	@Test
	public void testGetAllPatients() {
		assertTrue(MedicalRescordService.getReference().getAllPatients().stream().count() == 2);
	}

	@Test
	public void testGetPatientsWithAllergies() {
		MedicalRescordService.getReference().getMedicalRecord("0000").getHistory().addAllergy(new Allergey("Nuts"));
		assertTrue(MedicalRescordService.getReference().getPatientsWithAllergies("Nuts").size() == 1 );
		MedicalRescordService.getReference().getMedicalRecord("1111").getHistory().addAllergy(new Allergey("Nuts"));
		assertFalse("Does not list more than one patient with allergy", MedicalRescordService.getReference().getPatientsWithAllergies("Nuts").size() == 1 );
	}
	@Test
	public void testAllergicToMedication() {
		MedicalRescordService.getReference().getMedicalRecord("0000").getHistory().addAllergy(new Allergey("Nuts"));
		MedicalRescordService.getReference().getMedicalRecord("0000").getHistory().addMedication(new Medication("Nuts", "Start","End", "Dose"));
		assertFalse("Allows patients with an allergy to medication to be prescribed that medication", 
				MedicalRescordService.getReference().getMedicalRecord("0000").getHistory().getAlergies().stream().anyMatch(Allergey -> Allergey.getName().equals("Nuts"))
				&& MedicalRescordService.getReference().getMedicalRecord("0000").getHistory().getAllMedications().stream().anyMatch(Medication -> Medication.getName().equals("Nuts"))

				);
	}
	@Test
	public void testChangePatients() {
		MedicalRescordService.getReference().addPatient("Three", "3333");
		MedicalRescordService.getReference().getPatient("3333").setId("0000");
		List<Patient> pats = MedicalRescordService.getReference().getAllPatients().stream().filter(Patient -> Patient.getId().equals("0000")).collect(Collectors.toList());
		assertFalse("Allows changing patient ID to ID already taken", pats.size() == 2);
	}
}
