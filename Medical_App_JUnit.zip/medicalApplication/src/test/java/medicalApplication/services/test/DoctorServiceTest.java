package medicalApplication.services.test;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.BeforeClass;
import org.junit.Test;

import medical.com.medicalApplication.model.Doctor;
import medical.com.medicalApplication.services.DoctorService;

public class DoctorServiceTest {
	
	private static List<Doctor> doctors;
	
	@BeforeClass
	public static void BeforeClass() {
		DoctorService.getReference().addDoctor("Doc Holliday", "1234");
		DoctorService.getReference().addDoctor("Doc", "0000");
		doctors = DoctorService.getReference().getAllDoctors();
	}

	@Test
	public void testGetAllDoctors() {
		assertTrue(doctors.size()==3);
	}

	@Test
	public void testAddDoctor() {
		Doctor doc = new Doctor("Sanchez", "0123");
		DoctorService.getReference().addDoctor(doc.getName(), doc.getId());
		assertTrue(doctors.size()==3);
	}
	@Test
	public void testSameDoctor() {
		DoctorService.getReference().addDoctor("The Doctor", "0000");
		assertFalse("Allows doctors with same ID", DoctorService.getReference().getAllDoctors().stream().count()>3);
	}

}
